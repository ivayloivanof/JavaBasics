package firstLevelShop;

public class Messages {
   public final static String OutOfStockMessage = "The product is out of stock!";
   public final static String NotEnoughMoneyMessage = "You do not have enough money to buy this product!";
   public final static String ProductExpiredMessage = "The product is expired!";
   public final static String NoPermissionMessage = "You are too young to buy this product!!";

    static {

    }
}
