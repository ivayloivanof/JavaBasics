package firstLevelShop.exceptions;

public class NoPermissionException extends Exception {

    public NoPermissionException(String message){
        super(message);
    }
}
