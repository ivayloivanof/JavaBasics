package firstLevelShop.interfaces;

public interface Buyable {
    double getPrice();
}
