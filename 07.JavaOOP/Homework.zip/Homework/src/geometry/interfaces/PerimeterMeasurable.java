package geometry.interfaces;

public interface PerimeterMeasurable {
    double getPerimeter();
}
