package geometry.interfaces;

public interface VolumeMeasurable {
    double getVolume();
}
