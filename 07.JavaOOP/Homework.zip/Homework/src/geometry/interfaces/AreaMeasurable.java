package geometry.interfaces;

public interface AreaMeasurable {
    double getArea();
}
