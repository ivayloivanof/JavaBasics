package homework;

public class DecimalToHexadecimal {

	public static String decimalToHexadecimal(int decimal) {
	        
	    return Integer.toHexString(decimal); 
	}
}
