package homework;

public class RectangleArea {
	public static long rectangleArea(int a, int b) {
				
		long area = a * b;
		
		return area;
	}
}
