package homework;

public class SumTwoNumbers {
	
	public static void main(String[] args) {
		printSum(5, 3);
		printSum(12, -7);
		//printSum(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
	}
	
	public static void printSum(int a, int b) {
		System.out.println(a + b);
	}
}