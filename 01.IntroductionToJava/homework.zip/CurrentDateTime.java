package homework;

import java.util.Date;

public class CurrentDateTime {
	public static void main(String[] args) {
		System.out.println(new Date());
	}
}