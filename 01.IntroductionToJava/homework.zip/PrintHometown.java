package homework;

public class PrintHometown {
	public static void main(String[] args) {
		String townName = "Samokov";
		System.out.println(townName);
	}
}